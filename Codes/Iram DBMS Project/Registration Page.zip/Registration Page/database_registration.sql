create database hotel_management_project;
use hotel_management_project;

Create Table registration (
first_name varchar(50),
middle_name varchar(50),
last_name varchar(50), 
email_id varchar(50),
id_proof varchar(50),
dob date,
accompanying_members int(5));

select * from registration;