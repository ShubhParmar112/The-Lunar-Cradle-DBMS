document.getElementById('booking-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const primaryGuest = document.getElementById('primary-guest').value;
    const guests = document.getElementById('guests').value;
    const checkIn = document.getElementById('check-in').value;
    const checkOut = document.getElementById('check-out').value;
    const nights = document.getElementById('nights').value;
    const bookingStatus = document.getElementById('booking-status');
    const bookBtn = document.getElementById('book-btn');

    if (!primaryGuest || !guests || !checkIn || !checkOut || !nights) {
        bookingStatus.textContent = 'Please fill in all fields.';
        bookingStatus.classList.remove('hidden');
        return;
    }

    if (guests < 0 || nights < 1) {
        bookingStatus.textContent = 'Number of guests cannot be negative, and nights must be at least 1.';
        bookingStatus.classList.remove('hidden');
        return;
    }

    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    if (checkOutDate <= checkInDate) {
        bookingStatus.textContent = 'Check-out date must be after check-in date.';
        bookingStatus.classList.remove('hidden');
        return;
    }

    bookBtn.textContent = 'Processing...';
    bookBtn.disabled = true;

    setTimeout(() => {
        const confirmationMessage = `Booking confirmed! Thank you, ${primaryGuest}, for reserving your stay at The Lunar Gradle from ${checkIn} to ${checkOut} for ${guests} accompanying member(s) and ${nights} night(s).`;
        bookingStatus.textContent = confirmationMessage;
        bookingStatus.classList.remove('hidden');

        bookBtn.textContent = 'Book Now';
        bookBtn.disabled = false;
        this.reset();
    }, 2000);
});

// Choose Room redirection
document.getElementById('choose-room-btn').addEventListener('click', function() {
    window.location.href = "ROOMS.html";  // Change this if the file is elsewhere
});
